import { MusicalKey } from '../types';

// Notes in standard order
const notes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const flatNotes = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];

// Map to standardize note names
const noteMap: Record<string, number> = {
  'C': 0, 'C#': 1, 'Db': 1,
  'D': 2, 'D#': 3, 'Eb': 3,
  'E': 4,
  'F': 5, 'F#': 6, 'Gb': 6,
  'G': 7, 'G#': 8, 'Ab': 8,
  'A': 9, 'A#': 10, 'Bb': 10,
  'B': 11
};

/**
 * Get the numeric value of a key (0 for C, 1 for C#/Db, etc.)
 */
export function getKeyNumber(key: MusicalKey): number {
  return noteMap[key];
}

/**
 * Transpose a single note from one key to another
 */
export function transposeNote(note: string, fromKey: MusicalKey, toKey: MusicalKey): string {
  const fromKeyNumber = getKeyNumber(fromKey);
  const toKeyNumber = getKeyNumber(toKey);
  const interval = toKeyNumber - fromKeyNumber;
  
  // Handle case where note has no accidental
  if (noteMap[note] !== undefined) {
    const noteNumber = noteMap[note];
    const newNoteNumber = (noteNumber + interval + 12) % 12;
    
    // Determine whether to use sharps or flats based on target key
    if (toKey.includes('b')) {
      return flatNotes[newNoteNumber];
    } else {
      return notes[newNoteNumber];
    }
  }
  
  // Parse complex note (like Cm7, D/F#, etc.)
  const rootNoteMatch = note.match(/^([A-G][b#]?)/);
  if (!rootNoteMatch) return note; // Can't parse this note
  
  const rootNote = rootNoteMatch[1];
  const rootNoteNumber = noteMap[rootNote];
  const newRootNoteNumber = (rootNoteNumber + interval + 12) % 12;
  
  // Determine whether to use sharps or flats based on target key
  const newRootNote = toKey.includes('b') ? flatNotes[newRootNoteNumber] : notes[newRootNoteNumber];
  
  // Replace the root note in the original chord
  return note.replace(/^([A-G][b#]?)/, newRootNote);
}

/**
 * Transpose a chord from one key to another
 */
export function transposeChord(chord: string, fromKey: MusicalKey, toKey: MusicalKey): string {
  // If the chord has a slash (like G/B), transpose both parts
  if (chord.includes('/')) {
    const [baseChord, bassNote] = chord.split('/');
    const transposedBase = transposeNote(baseChord, fromKey, toKey);
    const transposedBass = transposeNote(bassNote, fromKey, toKey);
    return `${transposedBase}/${transposedBass}`;
  }
  
  return transposeNote(chord, fromKey, toKey);
}

/**
 * Generate a scale based on key and type
 */
export function generateScale(key: MusicalKey, type: 'major' | 'minor'): string[] {
  const keyNumber = getKeyNumber(key);
  const useFlats = key.includes('b');
  
  // Intervals for major and minor scales (in half-steps)
  const majorIntervals = [0, 2, 4, 5, 7, 9, 11];
  const minorIntervals = [0, 2, 3, 5, 7, 8, 10];
  
  const intervals = type === 'major' ? majorIntervals : minorIntervals;
  
  // Generate the scale notes
  return intervals.map(interval => {
    const noteIndex = (keyNumber + interval) % 12;
    return useFlats ? flatNotes[noteIndex] : notes[noteIndex];
  });
}

/**
 * Calculate the capo position needed to play in target key using shapes from original key
 */
export function calculateCapoPosition(originalKey: MusicalKey, targetKey: MusicalKey): number {
  const originalKeyNumber = getKeyNumber(originalKey);
  const targetKeyNumber = getKeyNumber(targetKey);
  
  // Calculate the number of half-steps up from original to target
  const halfSteps = (targetKeyNumber - originalKeyNumber + 12) % 12;
  
  return halfSteps;
}

/**
 * Get common chord progressions for a key
 */
export function getCommonProgressions(key: MusicalKey): Record<string, string[]> {
  const majorScale = generateScale(key, 'major');
  
  // Roman numerals for chord progressions
  const progressions: Record<string, number[][]> = {
    "I-IV-V": [[0], [3], [4]],
    "I-V-vi-IV": [[0], [4], [5], [3]],
    "ii-V-I": [[1], [4], [0]],
    "I-vi-IV-V": [[0], [5], [3], [4]],
    "vi-IV-I-V": [[5], [3], [0], [4]],
    "I-IV-I-V": [[0], [3], [0], [4]]
  };
  
  // Convert progression indices to actual chords
  const result: Record<string, string[]> = {};
  for (const [name, indices] of Object.entries(progressions)) {
    result[name] = indices.map(chordIndices => {
      const rootIndex = chordIndices[0];
      const rootNote = majorScale[rootIndex];
      return rootNote + (rootIndex === 1 || rootIndex === 2 || rootIndex === 5 ? 'm' : '');
    });
  }
  
  return result;
}