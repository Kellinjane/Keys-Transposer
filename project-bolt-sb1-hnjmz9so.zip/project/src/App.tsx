import React from 'react';
import { Music } from 'lucide-react';
import KeyTransposer from './components/KeyTransposer';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-purple-100 dark:from-gray-900 dark:to-purple-950 flex flex-col">
      <header className="bg-white dark:bg-gray-800 shadow-md p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Music className="h-8 w-8 text-purple-600 dark:text-purple-400" />
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">KeyShift</h1>
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-300">
            Transpose with confidence
          </div>
        </div>
      </header>
      
      <main className="flex-grow container mx-auto p-4 md:p-6 lg:p-8">
        <KeyTransposer />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;