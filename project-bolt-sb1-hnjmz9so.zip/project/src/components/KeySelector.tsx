import React from 'react';
import { MusicalKey } from '../types';

interface KeySelectorProps {
  label: string;
  selectedKey: MusicalKey;
  onChange: (key: MusicalKey) => void;
}

const KeySelector: React.FC<KeySelectorProps> = ({ label, selectedKey, onChange }) => {
  const musicalKeys: MusicalKey[] = [
    'C', 'C#', 'Db', 'D', 'D#', 'Eb', 'E', 'F', 'F#', 'Gb', 'G', 'G#', 'Ab', 'A', 'A#', 'Bb', 'B'
  ];

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
        {label}:
      </label>
      <div className="grid grid-cols-6 sm:grid-cols-6 gap-2">
        {musicalKeys.map((key) => (
          <button
            key={key}
            className={`py-2 px-3 text-sm font-medium rounded-md transition-all ${
              selectedKey === key
                ? 'bg-purple-600 text-white shadow-md transform scale-105'
                : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600'
            }`}
            onClick={() => onChange(key)}
          >
            {key}
          </button>
        ))}
      </div>
    </div>
  );
};

export default KeySelector;