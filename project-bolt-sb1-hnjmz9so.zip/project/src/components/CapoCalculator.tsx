import React from 'react';
import { MusicalKey } from '../types';
import { calculateCapoPosition, getKeyNumber } from '../utils/musicTheory';

interface CapoCalculatorProps {
  originalKey: MusicalKey;
  targetKey: MusicalKey;
}

const CapoCalculator: React.FC<CapoCalculatorProps> = ({ originalKey, targetKey }) => {
  const capoPosition = calculateCapoPosition(originalKey, targetKey);
  const playChord = getKeyNumber(targetKey) - capoPosition >= 0 
    ? (getKeyNumber(targetKey) - capoPosition >= 0 
      ? { key: getKeyFromNumber(getKeyNumber(targetKey) - capoPosition), position: capoPosition } 
      : { key: originalKey, position: 0 })
    : { key: originalKey, position: 0 };
  
  const renderGuitar = () => {
    return (
      <div className="relative">
        <div className="w-full h-8 bg-yellow-900 rounded-l-md flex items-center justify-start">
          <div className="w-10 h-7 bg-black rounded-sm mx-1"></div>
        </div>
        <div className="w-full h-48 bg-gradient-to-r from-yellow-800 to-yellow-700 relative">
          {/* Fret markers */}
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((fret) => (
            <div 
              key={fret} 
              className={`absolute top-0 w-px h-full bg-gray-400 ${
                fret === 0 ? 'left-0 w-1 bg-gray-200' : ''
              }`}
              style={{ left: `${fret * (100 / 12)}%` }}
            >
              {[3, 5, 7, 9].includes(fret) && (
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-2 h-2 rounded-full bg-white opacity-50"></div>
              )}
              {fret === 12 && (
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 flex flex-col items-center">
                  <div className="w-2 h-2 rounded-full bg-white opacity-50 mb-4"></div>
                  <div className="w-2 h-2 rounded-full bg-white opacity-50"></div>
                </div>
              )}
              <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs text-gray-500">
                {fret}
              </div>
            </div>
          ))}
          
          {/* Capo position marker */}
          {capoPosition > 0 && (
            <div 
              className="absolute top-0 w-2 h-full bg-purple-600 z-10 rounded-sm shadow-md"
              style={{ left: `${(capoPosition - 0.5) * (100 / 12)}%` }}
            >
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs font-bold text-purple-600">
                Capo
              </div>
            </div>
          )}
          
          {/* Strings */}
          {[0, 1, 2, 3, 4, 5].map((string) => (
            <div 
              key={string} 
              className="absolute w-full h-px bg-gray-200"
              style={{ top: `${string * 20 + 15}%` }}
            ></div>
          ))}
        </div>
      </div>
    );
  };
  
  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h3 className="text-lg font-medium text-gray-800 dark:text-white mb-4">
          Capo Calculator for Guitar
        </h3>
        
        <div className="bg-white dark:bg-gray-700 rounded-lg p-4 shadow-sm">
          {capoPosition > 0 ? (
            <div className="text-center">
              <p className="text-gray-700 dark:text-gray-300 mb-2">
                To play in <span className="text-purple-600 dark:text-purple-400 font-medium">{targetKey}</span> while
                using <span className="text-gray-800 dark:text-white font-medium">{originalKey}</span> chord shapes:
              </p>
              <p className="text-xl font-bold text-purple-600 dark:text-purple-400 mb-4">
                Put capo on fret {capoPosition} and play in {playChord.key}
              </p>
            </div>
          ) : (
            <div className="text-center">
              <p className="text-gray-700 dark:text-gray-300">
                No capo needed to play in {targetKey} using {originalKey} chord shapes.
              </p>
              <p className="text-gray-700 dark:text-gray-300 mt-2">
                Try selecting different keys to see capo positions.
              </p>
            </div>
          )}
          
          {renderGuitar()}
          
          <div className="mt-6 p-4 bg-yellow-50 dark:bg-yellow-900/30 rounded-md">
            <h4 className="font-medium text-yellow-800 dark:text-yellow-200 mb-2">How It Works</h4>
            <p className="text-sm text-yellow-700 dark:text-yellow-300">
              A capo raises the pitch of all strings by one half-step per fret.
              This lets you use familiar chord shapes while playing in a different key.
            </p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-700 rounded-lg p-4 shadow-sm">
          <h4 className="font-medium text-gray-800 dark:text-white mb-2">Common Capo Usage</h4>
          <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-2">
            <li>• Capo 1: Play G shapes for G# songs</li>
            <li>• Capo 2: Play G shapes for A songs</li>
            <li>• Capo 3: Play G shapes for Bb songs</li>
            <li>• Capo 7: Play C shapes for G songs</li>
          </ul>
        </div>
        
        <div className="bg-white dark:bg-gray-700 rounded-lg p-4 shadow-sm">
          <h4 className="font-medium text-gray-800 dark:text-white mb-2">For Vocalists</h4>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            Using a capo helps guitarists match a vocalist's preferred key
            while still using familiar chord shapes.
          </p>
        </div>
        
        <div className="bg-white dark:bg-gray-700 rounded-lg p-4 shadow-sm">
          <h4 className="font-medium text-gray-800 dark:text-white mb-2">Sound Change</h4>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            A capo changes the timbre of your guitar, often creating a brighter,
            more "jangly" sound that works well for folk and acoustic pop.
          </p>
        </div>
      </div>
    </div>
  );
};

// Helper function to convert key number back to key
function getKeyFromNumber(num: number): MusicalKey {
  const keys: MusicalKey[] = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  return keys[((num % 12) + 12) % 12];
}

export default CapoCalculator;