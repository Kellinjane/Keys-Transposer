import React from 'react';
import { MusicalKey } from '../types';

interface ChordDisplayProps {
  originalChords: string;
  transposedChords: string;
  originalKey: MusicalKey;
  targetKey: MusicalKey;
}

const ChordDisplay: React.FC<ChordDisplayProps> = ({ 
  originalChords, 
  transposedChords,
  originalKey,
  targetKey
}) => {
  if (!originalChords.trim()) {
    return (
      <div className="p-4 bg-purple-50 dark:bg-gray-700 rounded-md text-gray-600 dark:text-gray-300 text-center">
        Enter some chords above to see the transposition result
      </div>
    );
  }

  const originalChordArray = originalChords.split(' ').filter(chord => chord.trim() !== '');
  const transposedChordArray = transposedChords.split(' ').filter(chord => chord.trim() !== '');

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-800 dark:text-white">
        Transposition Result ({originalKey} → {targetKey})
      </h3>
      
      <div className="overflow-x-auto">
        <table className="min-w-full border-collapse">
          <thead>
            <tr>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-500 dark:text-gray-300 border-b dark:border-gray-700">
                Original ({originalKey})
              </th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-500 dark:text-gray-300 border-b dark:border-gray-700">
                Transposed ({targetKey})
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="px-4 py-3 text-gray-800 dark:text-gray-200 text-lg font-medium tracking-wide">
                {originalChordArray.map((chord, index) => (
                  <span 
                    key={index} 
                    className="inline-block mr-3 min-w-10 text-center"
                  >
                    {chord}
                  </span>
                ))}
              </td>
              <td className="px-4 py-3 text-purple-600 dark:text-purple-400 text-lg font-medium tracking-wide">
                {transposedChordArray.map((chord, index) => (
                  <span 
                    key={index} 
                    className="inline-block mr-3 min-w-10 text-center animate-fadeIn"
                  >
                    {chord}
                  </span>
                ))}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div className="p-4 bg-yellow-50 dark:bg-yellow-900/30 rounded-md text-sm">
        <p className="text-yellow-700 dark:text-yellow-200">
          <strong>Tip:</strong> Try common progressions like "C F G Am" or "G Em C D" to see how they sound in different keys.
        </p>
      </div>
    </div>
  );
};

export default ChordDisplay;