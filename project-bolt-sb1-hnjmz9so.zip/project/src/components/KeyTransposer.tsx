import React, { useState, useEffect } from 'react';
import KeySelector from './KeySelector';
import ChordDisplay from './ChordDisplay';
import ScaleVisualizer from './ScaleVisualizer';
import CapoCalculator from './CapoCalculator';
import TranspositionHistory from './TranspositionHistory';
import { transposeChord, transposeNote } from '../utils/musicTheory';
import { MusicalKey, TranspositionHistoryItem } from '../types';

const KeyTransposer: React.FC = () => {
  const [originalKey, setOriginalKey] = useState<MusicalKey>('C');
  const [targetKey, setTargetKey] = useState<MusicalKey>('G');
  const [chordInput, setChordInput] = useState<string>('C Am F G');
  const [transposedChords, setTransposedChords] = useState<string>('');
  const [history, setHistory] = useState<TranspositionHistoryItem[]>([]);
  const [activeTab, setActiveTab] = useState<'chords' | 'scales' | 'capo'>('chords');

  useEffect(() => {
    if (originalKey && targetKey && chordInput) {
      const chords = chordInput.split(' ').filter(chord => chord.trim() !== '');
      const transposed = chords.map(chord => 
        transposeChord(chord, originalKey, targetKey)
      ).join(' ');
      
      setTransposedChords(transposed);
    }
  }, [originalKey, targetKey, chordInput]);

  const handleTranspose = () => {
    // Save to history
    const newHistoryItem: TranspositionHistoryItem = {
      id: Date.now(),
      originalKey,
      targetKey,
      originalChords: chordInput,
      transposedChords
    };
    
    setHistory(prev => [newHistoryItem, ...prev.slice(0, 9)]);
  };

  const handleHistorySelect = (item: TranspositionHistoryItem) => {
    setOriginalKey(item.originalKey);
    setTargetKey(item.targetKey);
    setChordInput(item.originalChords);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 max-w-5xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Key Transposer</h2>
        <p className="text-gray-600 dark:text-gray-300">
          Change the key of your songs easily with this transposition tool.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <KeySelector 
          label="Original Key"
          selectedKey={originalKey}
          onChange={setOriginalKey}
        />
        <KeySelector 
          label="Target Key"
          selectedKey={targetKey}
          onChange={setTargetKey}
        />
      </div>
      
      <div className="mb-8">
        <div className="flex border-b border-gray-200 dark:border-gray-700 mb-4">
          <button
            className={`py-2 px-4 font-medium text-sm focus:outline-none ${
              activeTab === 'chords' 
                ? 'text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400' 
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('chords')}
          >
            Chord Progression
          </button>
          <button
            className={`py-2 px-4 font-medium text-sm focus:outline-none ${
              activeTab === 'scales' 
                ? 'text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400' 
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('scales')}
          >
            Scales
          </button>
          <button
            className={`py-2 px-4 font-medium text-sm focus:outline-none ${
              activeTab === 'capo' 
                ? 'text-purple-600 dark:text-purple-400 border-b-2 border-purple-600 dark:border-purple-400' 
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('capo')}
          >
            Capo Calculator
          </button>
        </div>
        
        {activeTab === 'chords' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Enter chord progression (space separated):
              </label>
              <textarea
                value={chordInput}
                onChange={(e) => setChordInput(e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-700 dark:text-white"
                rows={3}
                placeholder="e.g. C Am F G"
              />
            </div>
            
            <div>
              <button
                onClick={handleTranspose}
                className="px-4 py-2 bg-purple-600 text-white rounded-md shadow hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 transition-colors"
              >
                Transpose
              </button>
            </div>
            
            <ChordDisplay 
              originalChords={chordInput} 
              transposedChords={transposedChords} 
              originalKey={originalKey}
              targetKey={targetKey}
            />
          </div>
        )}
        
        {activeTab === 'scales' && (
          <ScaleVisualizer originalKey={originalKey} targetKey={targetKey} />
        )}
        
        {activeTab === 'capo' && (
          <CapoCalculator originalKey={originalKey} targetKey={targetKey} />
        )}
      </div>
      
      <TranspositionHistory 
        history={history} 
        onSelect={handleHistorySelect} 
      />
    </div>
  );
};

export default KeyTransposer;