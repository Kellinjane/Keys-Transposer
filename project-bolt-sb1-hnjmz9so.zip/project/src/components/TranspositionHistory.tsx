import React from 'react';
import { Clock } from 'lucide-react';
import { TranspositionHistoryItem } from '../types';

interface TranspositionHistoryProps {
  history: TranspositionHistoryItem[];
  onSelect: (item: TranspositionHistoryItem) => void;
}

const TranspositionHistory: React.FC<TranspositionHistoryProps> = ({ history, onSelect }) => {
  if (history.length === 0) {
    return null;
  }

  return (
    <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
      <div className="flex items-center mb-4">
        <Clock className="w-5 h-5 text-gray-500 dark:text-gray-400 mr-2" />
        <h3 className="text-lg font-medium text-gray-800 dark:text-white">
          Recent Transpositions
        </h3>
      </div>
      
      <div className="space-y-2">
        {history.map((item) => (
          <div 
            key={item.id}
            className="bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-md p-3 hover:bg-gray-50 dark:hover:bg-gray-600 cursor-pointer transition-colors"
            onClick={() => onSelect(item)}
          >
            <div className="flex justify-between items-center">
              <div className="font-medium text-gray-700 dark:text-gray-200">
                {item.originalKey} → {item.targetKey}
              </div>
              <div className="text-sm text-gray-500 dark:text-gray-400">
                {formatTime(item.id)}
              </div>
            </div>
            <div className="mt-1 text-sm text-gray-600 dark:text-gray-300 truncate">
              <span className="text-gray-500 dark:text-gray-400 mr-2">Original:</span>
              {item.originalChords}
            </div>
            <div className="mt-1 text-sm text-purple-600 dark:text-purple-400 truncate">
              <span className="text-gray-500 dark:text-gray-400 mr-2">Transposed:</span>
              {item.transposedChords}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

function formatTime(timestamp: number): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) {
    return 'just now';
  } else if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60);
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  } else if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  } else {
    return date.toLocaleString();
  }
}

export default TranspositionHistory;