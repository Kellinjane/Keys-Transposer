import React, { useState } from 'react';
import { MusicalKey } from '../types';
import { generateScale } from '../utils/musicTheory';

interface ScaleVisualizerProps {
  originalKey: MusicalKey;
  targetKey: MusicalKey;
}

const ScaleVisualizer: React.FC<ScaleVisualizerProps> = ({ originalKey, targetKey }) => {
  const [scaleType, setScaleType] = useState<'major' | 'minor'>('major');
  
  const originalScale = generateScale(originalKey, scaleType);
  const targetScale = generateScale(targetKey, scaleType);
  
  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex space-x-4">
        <button
          className={`px-4 py-2 rounded-md text-sm font-medium ${
            scaleType === 'major'
              ? 'bg-purple-600 text-white'
              : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
          }`}
          onClick={() => setScaleType('major')}
        >
          Major Scale
        </button>
        <button
          className={`px-4 py-2 rounded-md text-sm font-medium ${
            scaleType === 'minor'
              ? 'bg-purple-600 text-white'
              : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
          }`}
          onClick={() => setScaleType('minor')}
        >
          Minor Scale
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-3">
          <h3 className="text-lg font-medium text-gray-800 dark:text-white">
            {originalKey} {scaleType}
          </h3>
          <div className="flex flex-wrap gap-2">
            {originalScale.map((note, index) => (
              <div 
                key={index} 
                className="w-12 h-12 flex items-center justify-center rounded-full bg-white dark:bg-gray-700 border-2 border-purple-200 dark:border-purple-800 shadow-sm"
              >
                <span className="text-gray-800 dark:text-white font-medium">
                  {note}
                </span>
              </div>
            ))}
          </div>
          
          <div className="flex space-x-2 mt-4">
            {originalScale.map((note, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="text-xs text-gray-500 dark:text-gray-400">{index + 1}</div>
                <div className="text-sm font-medium text-gray-700 dark:text-gray-300">{note}</div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-3">
          <h3 className="text-lg font-medium text-gray-800 dark:text-white">
            {targetKey} {scaleType}
          </h3>
          <div className="flex flex-wrap gap-2">
            {targetScale.map((note, index) => (
              <div 
                key={index} 
                className="w-12 h-12 flex items-center justify-center rounded-full bg-white dark:bg-gray-700 border-2 border-purple-400 dark:border-purple-600 shadow-sm"
              >
                <span className="text-purple-600 dark:text-purple-400 font-medium">
                  {note}
                </span>
              </div>
            ))}
          </div>
          
          <div className="flex space-x-2 mt-4">
            {targetScale.map((note, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="text-xs text-gray-500 dark:text-gray-400">{index + 1}</div>
                <div className="text-sm font-medium text-purple-600 dark:text-purple-400">{note}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="mt-6">
        <h3 className="text-lg font-medium text-gray-800 dark:text-white mb-3">
          Piano Visualization
        </h3>
        <div className="bg-gray-800 p-4 rounded-md overflow-x-auto">
          <div className="flex h-32 min-w-[550px]">
            {renderPianoKeys(originalKey, targetKey, scaleType)}
          </div>
        </div>
      </div>
    </div>
  );
};

const renderPianoKeys = (originalKey: MusicalKey, targetKey: MusicalKey, scaleType: 'major' | 'minor') => {
  const originalScale = generateScale(originalKey, scaleType);
  const targetScale = generateScale(targetKey, scaleType);
  
  // A simple 2-octave piano representation
  const whiteKeys = ['C', 'D', 'E', 'F', 'G', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'A', 'B'];
  const blackKeys = [
    ['C#', 'Db'], ['D#', 'Eb'], null, ['F#', 'Gb'], ['G#', 'Ab'], ['A#', 'Bb'], null,
    ['C#', 'Db'], ['D#', 'Eb'], null, ['F#', 'Gb'], ['G#', 'Ab'], ['A#', 'Bb'], null
  ];
  
  // Helper to check if note is in scale
  const isInOriginalScale = (note: string) => originalScale.some(n => {
    if (note.includes('#') && n.includes('b')) return false;
    if (note.includes('b') && n.includes('#')) return false;
    return n === note || 
      (note === 'C#' && n === 'Db') || 
      (note === 'Db' && n === 'C#') ||
      (note === 'D#' && n === 'Eb') || 
      (note === 'Eb' && n === 'D#') ||
      (note === 'F#' && n === 'Gb') || 
      (note === 'Gb' && n === 'F#') ||
      (note === 'G#' && n === 'Ab') || 
      (note === 'Ab' && n === 'G#') ||
      (note === 'A#' && n === 'Bb') || 
      (note === 'Bb' && n === 'A#');
  });
  
  const isInTargetScale = (note: string) => targetScale.some(n => {
    if (note.includes('#') && n.includes('b')) return false;
    if (note.includes('b') && n.includes('#')) return false;
    return n === note || 
      (note === 'C#' && n === 'Db') || 
      (note === 'Db' && n === 'C#') ||
      (note === 'D#' && n === 'Eb') || 
      (note === 'Eb' && n === 'D#') ||
      (note === 'F#' && n === 'Gb') || 
      (note === 'Gb' && n === 'F#') ||
      (note === 'G#' && n === 'Ab') || 
      (note === 'Ab' && n === 'G#') ||
      (note === 'A#' && n === 'Bb') || 
      (note === 'Bb' && n === 'A#');
  });
  
  return (
    <div className="relative flex">
      {whiteKeys.map((note, index) => {
        const inOriginal = isInOriginalScale(note);
        const inTarget = isInTargetScale(note);
        
        let bgColor = 'bg-white';
        if (inOriginal && inTarget) {
          bgColor = 'bg-gradient-to-b from-purple-200 to-yellow-100';
        } else if (inOriginal) {
          bgColor = 'bg-purple-100';
        } else if (inTarget) {
          bgColor = 'bg-yellow-100';
        }
        
        let textColor = 'text-gray-800';
        if (inOriginal && inTarget) {
          textColor = 'text-purple-800';
        } else if (inOriginal) {
          textColor = 'text-purple-600';
        } else if (inTarget) {
          textColor = 'text-yellow-600';
        }
        
        return (
          <div 
            key={`white-${index}`} 
            className={`w-12 h-full ${bgColor} border border-gray-300 flex items-end justify-center pb-2 relative ${
              index === 0 ? 'rounded-l-md' : ''
            } ${index === whiteKeys.length - 1 ? 'rounded-r-md' : ''}`}
          >
            <span className={`${textColor} font-medium`}>{note}</span>
          </div>
        );
      })}
      
      {blackKeys.map((notes, index) => {
        if (!notes) return null;
        
        const inOriginal = notes.some(n => isInOriginalScale(n));
        const inTarget = notes.some(n => isInTargetScale(n));
        
        let bgColor = 'bg-gray-800';
        if (inOriginal && inTarget) {
          bgColor = 'bg-purple-800';
        } else if (inOriginal) {
          bgColor = 'bg-purple-700';
        } else if (inTarget) {
          bgColor = 'bg-yellow-700';
        }
        
        let textColor = 'text-white';
        
        const offset = index * 12 + (index >= 7 ? 0 : 0);
        
        return (
          <div 
            key={`black-${index}`} 
            className={`absolute w-8 h-20 ${bgColor} rounded-b-sm flex items-end justify-center pb-1 z-10`}
            style={{ left: `${offset + 8}px` }}
          >
            <span className={`${textColor} text-xs`}>{notes[0]}</span>
          </div>
        );
      })}
    </div>
  );
};

export default ScaleVisualizer;