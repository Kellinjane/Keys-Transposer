export type MusicalKey = 
  | 'C' | 'C#' | 'Db' 
  | 'D' | 'D#' | 'Eb' 
  | 'E' 
  | 'F' | 'F#' | 'Gb' 
  | 'G' | 'G#' | 'Ab' 
  | 'A' | 'A#' | 'Bb' 
  | 'B';

export interface TranspositionHistoryItem {
  id: number;
  originalKey: MusicalKey;
  targetKey: MusicalKey;
  originalChords: string;
  transposedChords: string;
}